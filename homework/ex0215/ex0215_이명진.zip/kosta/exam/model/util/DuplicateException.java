package kosta.exam.model.util;

public class DuplicateException extends Exception{
	public DuplicateException() {
		
	}
	
	public DuplicateException(String aa) {
		super(aa);
	}
	
}
