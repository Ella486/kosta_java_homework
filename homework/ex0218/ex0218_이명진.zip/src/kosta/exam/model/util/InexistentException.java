package kosta.exam.model.util;

public class InexistentException extends Exception{
	public InexistentException() {
		
	}
	public InexistentException(String ie) {
		super(ie);
	}
	
}
