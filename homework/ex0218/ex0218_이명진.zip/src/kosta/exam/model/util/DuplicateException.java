package kosta.exam.model.util;

public class DuplicateException extends Exception{
	public DuplicateException() {
		
	}
	
	public DuplicateException(String de) {
		super(de);
	}
	
}
