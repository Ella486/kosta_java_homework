package ex0209.interfaceExam02;

public interface Action {
	void work();
}
