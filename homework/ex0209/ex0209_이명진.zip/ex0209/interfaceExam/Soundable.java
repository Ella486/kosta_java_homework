package ex0209.interfaceExam;

public interface Soundable {
	String sound();
}
