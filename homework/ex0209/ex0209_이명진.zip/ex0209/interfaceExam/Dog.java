package ex0209.interfaceExam;

public class Dog implements Soundable {

	@Override
	public String sound() {
		
		return "�۸�";
	}

}
