package ex0209.interfaceExam;

public class Cat implements Soundable {

	@Override
	public String sound() {
		
		return "�߿�";
	}

}
