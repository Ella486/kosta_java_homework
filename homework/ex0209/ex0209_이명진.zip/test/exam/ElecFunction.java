package test.exam;

public interface ElecFunction {

	public void start();
	
	public void stop();

	public void display();
	
}