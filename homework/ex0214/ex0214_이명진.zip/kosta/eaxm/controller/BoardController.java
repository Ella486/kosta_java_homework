package kosta.eaxm.controller;


import kosta.eaxm.model.dto.Board;

public class BoardController {

	public static void getAllBoard() {
	
	}
	
	public static void getBoardByKind(String aa) {
		
	}
	
	public static void getBoardByNo(String aa, int no) {
		
	}
	
	public static void insertBoard(String aa, Board bd) {
		
	}
	
	public static void duplicateByNo(String aa , int no) {
		
	}
	
	public static void deleteBoard(String aa, int no) {
		
	}
	
	public static void updateBoard(Board bd, String aa) {
		
	}
	
	
}
