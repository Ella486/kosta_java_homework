package kosta.exam.view;

import java.util.Map;

import kosta.eaxm.model.dto.Board;

public class SuccessView {
	
	public static void printBoard(Map<String,Map<String,Board>> map) {
		
	}
	
	public static void printBoardByKind(String aa, Map<String,Board> map) {
		
	}
	
	public static void printBoardByNo(Board bd) {
		
	}
	
	public static void printMessage(String message) {
		
	}

}
