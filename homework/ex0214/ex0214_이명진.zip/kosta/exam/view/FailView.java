package kosta.exam.view;

public class FailView {
	public void errorMessage(String aa) {
		
	}
}
