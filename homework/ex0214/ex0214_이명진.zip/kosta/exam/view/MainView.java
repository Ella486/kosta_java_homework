package kosta.exam.view;

public class MainView {

	public static void main(String[] args) {
		

	}

}
