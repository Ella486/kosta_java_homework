package kosta.exam.model.util;

public class DuplicateException {
	public DuplicateException() {
		
	}
	
	public DuplicateException(int de) {
		
	}
	
}
