package kosta.exam.model.util;

public class InexistentException {
	public InexistentException() {
		
	}
	public InexistentException(String ie) {
		
	}
	
}
