 class Methodinvoke01{
    public int method01(int i, int j){//5 7
        System.out.println("�� ������ �� : " + (i*j));

		return i*j;
	}			
}
/////////////////////////////////////////////////////
class Methodinvoke02{
	public static int method02(int i, int j){ // 8  6
       System.out.println("�� �μ��� �� : " + (i+j));
	   return i+j;
	}	
}
/////////////////////////////////////////////////////////////////
class MethodInvokeExam{
	public static void main(String []args){
		
		//MethodInvoke01�� method01 ȣ��
        Methodinvoke01 m = new Methodinvoke01();
		int re = m.method01(5,7);
		System.out.println("ȣ�� ��� : " + re);

       System.out.println("------------------------");
		//MethodInvoke02�� method02 ȣ��
		int re2 = Methodinvoke02.method02(8, 6);
		System.out.println("ȣ�� ��� : " + re2);
	}
}

